
#include <devguid.h>    // for GUID_DEVCLASS_CDROM etc
#include <setupapi.h>
#include <cfgmgr32.h>   // for MAX_DEVICE_ID_LEN, CM_Get_Parent and CM_Get_Device_ID

#include <initguid.h>
#include <devpkey.h>
#include "Z:\WinDDK\7600.16385.1\inc\api\Ntddvdeo.h"


typedef BOOL (WINAPI *FN_SetupDiGetDeviceProperty)(
  __in       HDEVINFO DeviceInfoSet,
  __in       PSP_DEVINFO_DATA DeviceInfoData,
  __in       const DEVPROPKEY *PropertyKey,
  __out      DEVPROPTYPE *PropertyType,
  __out_opt  PBYTE PropertyBuffer,
  __in       DWORD PropertyBufferSize,
  __out_opt  PDWORD RequiredSize,
  __in       DWORD Flags
);


#pragma comment (lib, "setupapi.lib")

DWORD _GetNuma(char * pDevInst)
{
    unsigned i;
    DWORD dwSize, dwPropertyRegDataType;
    DEVPROPTYPE ulPropertyType;
    OSVERSIONINFO osvi;
    CONFIGRET r;
    HDEVINFO hDevInfo;
    SP_DEVINFO_DATA DeviceInfoData;
    const static LPCTSTR arPrefix[3] = {TEXT("VID_"), TEXT("PID_"), TEXT("MI_")};
    TCHAR szDeviceInstanceID [MAX_DEVICE_ID_LEN];
    TCHAR szDesc[1024];

    FN_SetupDiGetDeviceProperty fn_SetupDiGetDeviceProperty = (FN_SetupDiGetDeviceProperty)
        GetProcAddress(GetModuleHandle(TEXT("Setupapi.dll")), "SetupDiGetDevicePropertyW");

	DWORD dwNumaNode=-1;

    // List all connected USB devices
    hDevInfo = SetupDiGetClassDevs (NULL, TEXT("PCI"), NULL, DIGCF_PRESENT|DIGCF_ALLCLASSES);
    if (hDevInfo == INVALID_HANDLE_VALUE)
        return dwNumaNode;

    // Find the ones that are driverless
    for (i = 0; ; i++)  
	{
        DeviceInfoData.cbSize = sizeof (DeviceInfoData);
        if (!SetupDiEnumDeviceInfo(hDevInfo, i, &DeviceInfoData))
            break;

        r = CM_Get_Device_ID(DeviceInfoData.DevInst, szDeviceInstanceID , MAX_PATH, 0);
        if (r != CR_SUCCESS)
            continue;

        //printf ("%s\n", szDeviceInstanceID );

		if (!strcmp(pDevInst, szDeviceInstanceID))
		{

			if (SetupDiGetDeviceRegistryProperty (hDevInfo, &DeviceInfoData, SPDRP_DEVICEDESC,
												  &dwPropertyRegDataType, (BYTE*)szDesc,
												  sizeof(szDesc),   // The size, in bytes
												  &dwSize))
			{
			 //   printf ("    Device Description: \"%s\"\n", szDesc);
			}

			// Retreive the device description as reported by the device itself
			memset(&osvi, 0, sizeof(OSVERSIONINFO));
			osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

			if ( (GetVersionEx(&osvi) != 0)
				&& (osvi.dwBuildNumber >= 7000) ) 
			{
					// On Vista and earlier, we can use only SPDRP_DEVICEDESC
					// On Windows 7, the information we want ("Bus reported device description") is
					// accessed through DEVPKEY_Device_BusReportedDeviceDesc
					if (fn_SetupDiGetDeviceProperty && fn_SetupDiGetDeviceProperty (hDevInfo, &DeviceInfoData, &DEVPKEY_Device_Numa_Node,
																					&ulPropertyType, (BYTE*)szDesc, sizeof(szDesc), &dwSize, 0))
					{
						dwNumaNode =*(DWORD *)szDesc;			

						SetupDiDestroyDeviceInfoList(hDevInfo);

						return dwNumaNode;
					}
			}
		}
    }

	SetupDiDestroyDeviceInfoList(hDevInfo);

	return dwNumaNode;
}


DWORD GetNumaNode(char * pDeviceName, char * pDeviceKey)		//  "\\.\DISPLAY2"
{
	DWORD dwNode=-1;

    unsigned			i;
    HKEY                hKeyDeviceClasses = 0;
	DWORD				subKeyIndex = 0;
	DWORD				keyIndex = 0;
    char                keyName[256];
    DWORD               keyNameSize = 256;     
	
    // open deviceclasses registry key for mapping adapter names to video GUIDs
    // The GUID value before maps to GUID_DISPLAY_DEVICE_ARRIVAL, referenced in the previous call to SetupDiGetClassDevs.
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Control\\DeviceClasses\\{1ca05180-a699-450a-9a0c-de4fbe3ddd89}", 0, KEY_READ, &hKeyDeviceClasses) != ERROR_SUCCESS) 
	{
		return dwNode;
	}

	// enumerate registry keys

    while (1) 
	{
        if (RegEnumKeyExA(hKeyDeviceClasses, keyIndex++, keyName, &keyNameSize, NULL, NULL, NULL, NULL) == ERROR_NO_MORE_ITEMS) 
		{
			break;
		}
        keyNameSize = 256; 

        // Convert subkey name to all lowercase
        for (i = 0; i < MAX_DEVICE_ID_LEN; i++) {
            if (keyName[i] == '\0')
                break;
            keyName[i] = tolower(keyName[i]);            
        }

        HKEY hKeyDeviceClassElement = 0;

        DWORD deviceInstanceSize = 0;
        const char devParams[] = "\\Device Parameters";

		char deviceInstance[1024];

        HKEY hKeyEnum = 0;
        HKEY hKeyVideoGuid = 0;
        char videoGuid[1024];
        DWORD videoGuidSize;

        //get DeviceInstance field
        if (RegOpenKeyEx(hKeyDeviceClasses, keyName, 0, KEY_READ, &hKeyDeviceClassElement) != ERROR_SUCCESS) 
		{
 			return dwNode;
		}

		deviceInstanceSize=1024;
         if (RegQueryValueEx(hKeyDeviceClassElement, "DeviceInstance", NULL, NULL, (LPBYTE)deviceInstance, &deviceInstanceSize) != ERROR_SUCCESS) 
		{
        	return dwNode;
		}
        
        // get video GUID from Enum/PCI/VEN_10DE_etc/instance/Device Parameters/VideoID
        if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "System\\CurrentControlSet\\Enum", 0, KEY_READ, &hKeyEnum) != ERROR_SUCCESS) 
		{
	        RegCloseKey(hKeyDeviceClassElement);
        	return dwNode;
		}

		char pTmp[1024];

		sprintf(pTmp, "%s\\Device Parameters", deviceInstance);


        if (RegOpenKeyEx(hKeyEnum, pTmp, 0, KEY_READ, &hKeyVideoGuid) != ERROR_SUCCESS) 
		{
        	return dwNode;
		}
            
		videoGuidSize=1024;

        if (RegQueryValueEx(hKeyVideoGuid, "VideoID", NULL, NULL, (LPBYTE)videoGuid, &videoGuidSize) != ERROR_SUCCESS) 
		{
        	return dwNode;
		}

		//printf("looking for videoID %s\n", videoGuid);

		if (strstr(pDeviceKey, videoGuid))
		{
			char pNew[1024];

			memset(pNew, 0, 1024);

			// Convert subkey name to all uppercase
			for (i = 0; i < MAX_DEVICE_ID_LEN; i++) 
			{
				if (deviceInstance[i] == '\0')
					break;
				pNew[i] = toupper(deviceInstance[i]);            
			}

			dwNode=_GetNuma(pNew);

			if (dwNode!=-1)
				return dwNode;
		}
    }

	return (dwNode);
}






// to launch the process with the NUMA node set, example given for one application named "RTHDRIBL"


void RTHDRIBLThreadFunction(void * pData)
{
	VMThreadFunctionData * pVMThreadFunctionData=(VMThreadFunctionData *)pData;

    char * pPath = "C:\\rthdribl_2_0";
    char * pExeName = "rthdribl.exe";

    char * pOptions = aApps[pVMThreadFunctionData->dwSessionIndex].pContentName;

	char CommandLine[1024];

    STARTUPINFO si = {0};
    PROCESS_INFORMATION pi = {0};
    HANDLE hProcess=NULL;

	CreateDirectory("c:\\tmp", NULL);

	FILE * f= fopen("c:\\tmp\\t.bat", "wt");

	if (pVMThreadFunctionData->dwNumaNode!=-1)
		fprintf(f, "start  \"\" /wait  /node %d %s\\%s %s\n", pVMThreadFunctionData->dwNumaNode, pPath, pExeName, pOptions?pOptions:"");
	else
		fprintf(f, "start  \"\" /wait  %s\\%s %s\n", pPath, pExeName, pOptions?pOptions:"");


	fclose(f);

    si.cb = sizeof(STARTUPINFO);
    si.lpReserved = NULL;
    si.lpReserved2 = NULL;
    si.cbReserved2 = 0;
    si.lpDesktop = NULL;
    si.dwFlags = 0;


	sprintf(CommandLine, "cmd.exe /c %s", "c:\\tmp\\t.bat");

    if (CreateProcess( NULL,
                 CommandLine,
                 NULL,
                 NULL,
                 TRUE,
                 NORMAL_PRIORITY_CLASS,
                 NULL,
                 pPath,     // currentdir
                 &si,
                 &pi ))
	{
		hProcess=pi.hProcess; 
	}

	free(pNewEnv);

	SetEvent(pVMThreadFunctionData->hVMCreatedEvent);

    WaitForSingleObject(hProcess, INFINITE);

    printf ("Powering off session %d ...\n", pVMThreadFunctionData->dwVMIndex);

	EnterCriticalSection(&VMDataCS);

	gdwActiveVMs--;

	//cleaning up our slot
	memset(pVMThreadFunctionData, 0, sizeof(VMThreadFunctionData));

	LeaveCriticalSection(&VMDataCS);
}
